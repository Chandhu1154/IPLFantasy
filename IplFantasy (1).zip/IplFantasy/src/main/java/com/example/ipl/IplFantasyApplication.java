package com.example.ipl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IplFantasyApplication {

	public static void main(String[] args) {
		SpringApplication.run(IplFantasyApplication.class, args);
	}

}
