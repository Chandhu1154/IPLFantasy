package com.example.ipl.exception;

public class MatchAlreadyInProgressException extends Exception{

	public MatchAlreadyInProgressException() {
		super();
		// TODO Auto-generated constructor stub
	}

}
