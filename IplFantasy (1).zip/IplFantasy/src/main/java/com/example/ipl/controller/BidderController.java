package com.example.ipl.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.ipl.dto.BidderDto;
import com.example.ipl.dto.BiddingDto;


import com.example.ipl.exception.BidAlreadyExistForBidderException;
import com.example.ipl.exception.BidNotFoundException;
import com.example.ipl.exception.MatchNotFoundException;
import com.example.ipl.exception.UserAlreadyExistException;
import com.example.ipl.exception.UserNotExistException;
import com.example.ipl.service.IBidderService;

@RestController
public class BidderController {
@Autowired
  IBidderService service;
  
  @PostMapping("/register")
  public ResponseEntity registerBidder(@RequestBody BidderDto b) throws UserAlreadyExistException
  {
	  service.registerBidder(b);
	return new ResponseEntity("Register Succesfully",HttpStatus.OK);
  }
  @PostMapping("/login")
  public ResponseEntity loginBidder(@ RequestBody BidderDto b) throws UserNotExistException
  {
	  service.loginBidder(b);
	  return new ResponseEntity("Login Succesfully",HttpStatus.OK);
  }
  @PostMapping("/addbid")
  public ResponseEntity addBid(@RequestBody  BiddingDto bd) throws BidAlreadyExistForBidderException
  {
	  service.addBid(bd);
	  return  new ResponseEntity("Bid Added Succesfully",HttpStatus.OK);
  }
  @PutMapping("/updatebid/{id}")
  public ResponseEntity updateBid(@PathVariable int id,@RequestBody BiddingDto bd ) throws BidNotFoundException
  {
	  service.updateBid(id,bd.getTeamDetails().getTeamId());
	  return new ResponseEntity("Bid Update Succesfully",HttpStatus.ACCEPTED);
  }
  @DeleteMapping("/{id}")
  public ResponseEntity deleteBidById(@PathVariable  int id) throws BidNotFoundException
  {
	  service.deleteBidById(id);
	  return new ResponseEntity("Delete succesfully",HttpStatus.OK);
  }
  @GetMapping("/getmatch") 
  public ResponseEntity getAllMatches() throws MatchNotFoundException 
  {
	  
	 return new  ResponseEntity(service.getAllMatches(),HttpStatus.FOUND);
  }
  @GetMapping("/result/{id}")
  public ResponseEntity getResult(@PathVariable  int id) throws MatchNotFoundException
  {
	  
	  return new ResponseEntity (service.getResult(id),HttpStatus.FOUND);
  }
}
