package com.example.ipl.service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.ipl.repositry.AdminDao;
import com.example.ipl.repositry.AdminOperationsDao;
import com.example.ipl.repositry.AdminTeamDao;
import com.example.ipl.repositry.BidderDao;
import com.example.ipl.dto.AdminDto;
import com.example.ipl.dto.BidderDto;
import com.example.ipl.dto.MatchDto;
import com.example.ipl.dto.TeamDto;

import com.example.ipl.entities.Bidder;
import com.example.ipl.entities.MatchDetails;
import com.example.ipl.entities.TeamDetails;
import com.example.ipl.exception.BidderNotFoundException;
import com.example.ipl.exception.InvalidAdminException;
import com.example.ipl.exception.MatchAlreadyInProgressException;
import com.example.ipl.exception.MatchNotFoundException;
import com.example.ipl.exception.TeamAlreadyExistException;
@Service
public class AdminImplService implements IAdminService {
  @Autowired
  AdminDao adminDao;
  @Autowired
  AdminOperationsDao adminOperationDao;
  @Autowired
  AdminTeamDao adminTeamDao;
  @Autowired
  BidderDao bidderDao;
  
	@Override
	public String loginAdmin(AdminDto a) throws InvalidAdminException{
		if(adminDao.findAdmin(a.getUserName(),a.getPassword()).isEmpty())
		{
			throw new InvalidAdminException();
		}
		else
		{
		  return "Login Succesfully";
		}
	}
	@Override
	public MatchDetails addMatch(MatchDto md) throws MatchAlreadyInProgressException{
		if(adminOperationDao.findAll().isEmpty())
		{
			MatchDetails m=new MatchDetails();
			m.setDate(md.getDate());
			m.setMatchId(md.getMatchId());
		    m.setStadium(md.getStadium());
		    m.setTime(md.getTime());
		    m.setWinner(md.getWinner());
		    m.setTeamDetails1(md.getTeamDetails1());
		    m.setTeamDetails2(md.getTeamDetails2());
			return adminOperationDao.save(m);
		  
		}
		else
		{
			  throw new MatchAlreadyInProgressException();
		}
		
	}
	@Override
	public TeamDetails addTeam(TeamDto t) throws TeamAlreadyExistException {
		if(adminTeamDao.findByName(t.getTeamName()).isEmpty())
		{
		TeamDetails td=new TeamDetails();
	    td.setNumberOfPlayers(t.getNumberOfPlayers());
	    td.setTeamId(t.getTeamId());
	    td.setTeamName(t.getTeamName());
		return adminTeamDao.save(td);
		}
		else
		{
			throw new TeamAlreadyExistException();
		}
		
		
	}
	@Override
	public void updateMatchByDate(int id ,LocalDate date,LocalTime time) throws MatchNotFoundException{
		if(adminOperationDao.findById(id).isEmpty())
		{
			throw new MatchNotFoundException();
		}
		else
		{
         MatchDetails md=adminOperationDao.findById(id).get();
         md.setDate(date);
         md.setTime(time);
		 adminOperationDao.save(md);
		}
	}
	@Override
	public void updateMatchByTeam(int id,int teamoneId,int teamtwoId) throws MatchNotFoundException
	{
		if(adminOperationDao.findById(id).isEmpty())
		{
			throw new MatchNotFoundException();
		}
		else {
			MatchDetails md=adminOperationDao.findById(id).get();
			  TeamDetails teamone=new TeamDetails();
			  teamone.setTeamId(teamoneId);
			  TeamDetails teamtwo=new TeamDetails();
			  teamtwo.setTeamId(teamtwoId);
	          md.setTeamDetails1(teamone);
	          md.setTeamDetails2(teamtwo);
			  adminOperationDao.save(md);
		}
		   
	}
	@Override
	public void deleteMatchById(int id) throws MatchNotFoundException{
		Optional<MatchDetails> mO= adminOperationDao.findById(id);
	    MatchDetails md=mO.orElseThrow(()-> new MatchNotFoundException());
		MatchDto m=new MatchDto();
		m.setDate(md.getDate());
		m.setMatchId(md.getMatchId());
	    m.setStadium(md.getStadium());
	    m.setTeamDetails1(md.getTeamDetails1());
	    m.setTeamDetails2(md.getTeamDetails2());	
		adminOperationDao.deleteById(id);
		
	}
	@Override
	public List<BidderDto> getAllBidder()  throws BidderNotFoundException{
		Iterable<Bidder> bidder = bidderDao.findAll();
		List<BidderDto> bidderDtoList=new ArrayList<BidderDto>();
		bidder.forEach(bidders->{
			BidderDto bidderDto=new BidderDto();
		    bidderDto.setBidderId(bidders.getBidderId());
		    bidderDto.setBiddingDetails(bidders.getBiddingDetails());
		    bidderDto.setEmail(bidders.getEmail());
		    bidderDto.setName(bidders.getName());
		    bidderDto.setPassword(bidders.getPassword());
		    bidderDto.setPhoneNo(bidders.getPhoneNo());
		    bidderDto.setPoints(bidders.getPoints());
		    bidderDto.setUserName(bidders.getUserName());
		    bidderDtoList.add(bidderDto);
		    
		});
		if(bidderDtoList.isEmpty())
		{
			throw new BidderNotFoundException();
		
		}
		else
			return bidderDtoList;
	}
	@Override
	public void updateScore(int id, int score) throws BidderNotFoundException{
		  if(bidderDao.existsById(id))
		  {

	      Bidder b= bidderDao.findById(id).get();
	      b.setPoints(score);      
		  bidderDao.save(b);
		  }
		  else
		  {
			  throw new BidderNotFoundException();
		  }
	}
	@Override
	public void declareResult(int id, int win) throws MatchNotFoundException {
		if(adminOperationDao.existsById(id))
		{
		MatchDetails md=adminOperationDao.findById(id).get();
		md.setWinner(win);
		adminOperationDao.save(md);
		}
		else
		{
			throw new MatchNotFoundException();
		}
	}

}
