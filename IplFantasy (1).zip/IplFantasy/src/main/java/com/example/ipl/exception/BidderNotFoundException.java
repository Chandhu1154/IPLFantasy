package com.example.ipl.exception;

public class BidderNotFoundException extends Exception{

	public BidderNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

}
