package com.example.ipl.exception;

public class MatchNotFoundException extends Exception{

	public MatchNotFoundException()  {
		super();
		// TODO Auto-generated constructor stub
	}

}
