package com.example.ipl.exception;

public class UserNotExistException extends Exception{

	public UserNotExistException() {
		super();
		// TODO Auto-generated constructor stub
	}

}
