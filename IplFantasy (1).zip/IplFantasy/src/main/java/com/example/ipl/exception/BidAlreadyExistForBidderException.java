package com.example.ipl.exception;

public class BidAlreadyExistForBidderException extends Exception {

	public BidAlreadyExistForBidderException() {
		super();
		// TODO Auto-generated constructor stub
	}

}
