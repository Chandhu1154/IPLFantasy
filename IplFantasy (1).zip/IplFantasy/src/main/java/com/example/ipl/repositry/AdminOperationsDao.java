package com.example.ipl.repositry;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.ipl.entities.MatchDetails;

public interface AdminOperationsDao extends JpaRepository<MatchDetails, Integer>{

}
