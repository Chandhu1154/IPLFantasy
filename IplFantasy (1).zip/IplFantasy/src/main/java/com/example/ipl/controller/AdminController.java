package com.example.ipl.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.ipl.dto.AdminDto;
import com.example.ipl.dto.BidderDto;
import com.example.ipl.dto.MatchDto;
import com.example.ipl.dto.TeamDto;


import com.example.ipl.entities.MatchDetails;

import com.example.ipl.exception.BidderNotFoundException;
import com.example.ipl.exception.InvalidAdminException;
import com.example.ipl.exception.MatchAlreadyInProgressException;
import com.example.ipl.exception.MatchNotFoundException;
import com.example.ipl.exception.TeamAlreadyExistException;
import com.example.ipl.service.IAdminService;

@RestController
@RequestMapping("/admin")
public class AdminController {
@Autowired
IAdminService service;
@PostMapping("/login")
public ResponseEntity loginAdmin(@RequestBody  AdminDto a) throws InvalidAdminException
{
	
	return new ResponseEntity(service.loginAdmin(a),HttpStatus.OK);
}
@PostMapping("/addmatch") 
public ResponseEntity addMatch(@RequestBody MatchDto md) throws MatchAlreadyInProgressException
{
	service.addMatch(md);
	return new ResponseEntity("Match Add Succesfully",HttpStatus.CREATED);
}
@PostMapping("/addteam")
	public ResponseEntity addTeam(@RequestBody  TeamDto t) throws TeamAlreadyExistException
	{
	      service.addTeam(t);
	      return new ResponseEntity("Team Add Successfully",HttpStatus.CREATED); 
	}
@PutMapping("/updatematch/d/{id}") 
public ResponseEntity updateMatchDate(@PathVariable int id ,  @RequestBody  MatchDto md) throws MatchNotFoundException
{
	service.updateMatchByDate(id,md.getDate(),md.getTime());
	return new ResponseEntity("Match Update Succesfully",HttpStatus.OK);
}
@PutMapping("/updatematch/t/{id}") 
public ResponseEntity updateMatchTeam(@PathVariable int id ,  @RequestBody  MatchDto md) throws MatchNotFoundException
{
	service.updateMatchByTeam(id,md.getTeamDetails1().getTeamId(),md.getTeamDetails2().getTeamId());
	return new ResponseEntity("Match Update Succesfully",HttpStatus.OK);
}
@DeleteMapping("/{id}") 
public ResponseEntity deleteMatchById( @PathVariable  int id) throws MatchNotFoundException
{
	service.deleteMatchById(id);
	return new ResponseEntity(" Match Delete Succesfully",HttpStatus.OK); 
}
@GetMapping("/getBidder")
public ResponseEntity getAllBidder() throws BidderNotFoundException
{

	return new ResponseEntity(service.getAllBidder(),HttpStatus.OK); 
}
@PutMapping("/updatescore/{id}")
public ResponseEntity updateScore(@PathVariable  int id ,@RequestBody BidderDto b) throws BidderNotFoundException
{
	service.updateScore(id,b.getPoints());
	return  new ResponseEntity("Points was updated",HttpStatus.OK) ;
}
@PutMapping("/addresult/{id}")
public ResponseEntity declareResult(@PathVariable int id ,@RequestBody MatchDto m) throws MatchNotFoundException
{
	service.declareResult(id, m.getWinner());
	return  new ResponseEntity("Result is declared",HttpStatus.OK) ;
}
}
