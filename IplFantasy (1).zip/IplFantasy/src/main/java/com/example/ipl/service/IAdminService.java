package com.example.ipl.service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import com.example.ipl.dto.AdminDto;
import com.example.ipl.dto.BidderDto;
import com.example.ipl.dto.MatchDto;
import com.example.ipl.dto.TeamDto;

import com.example.ipl.entities.MatchDetails;
import com.example.ipl.entities.TeamDetails;
import com.example.ipl.exception.BidderNotFoundException;
import com.example.ipl.exception.InvalidAdminException;
import com.example.ipl.exception.MatchAlreadyInProgressException;
import com.example.ipl.exception.MatchNotFoundException;
import com.example.ipl.exception.TeamAlreadyExistException;

public interface IAdminService {

	public String loginAdmin(AdminDto a)throws InvalidAdminException;
	public MatchDetails addMatch(MatchDto md)throws MatchAlreadyInProgressException;
	public TeamDetails addTeam(TeamDto t)throws TeamAlreadyExistException;
	public void updateMatchByDate(int id,LocalDate date,LocalTime time) throws MatchNotFoundException;
	public void updateMatchByTeam(int id,int teamoneId,int teamtwoId) throws MatchNotFoundException;
	public void deleteMatchById(int id)throws MatchNotFoundException;
	public List<BidderDto> getAllBidder() throws BidderNotFoundException;
	public void updateScore(int id ,int score)throws BidderNotFoundException;
	public void  declareResult(int id ,int win)throws MatchNotFoundException;
	
	
}
