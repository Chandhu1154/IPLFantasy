package com.example.ipl.exception;

public class InvalidAdminException extends Exception{

	public InvalidAdminException() {
		super();
		// TODO Auto-generated constructor stub
	}

}
