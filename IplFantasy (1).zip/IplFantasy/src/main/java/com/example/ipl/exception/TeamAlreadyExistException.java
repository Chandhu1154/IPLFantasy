package com.example.ipl.exception;

public class TeamAlreadyExistException extends Exception {

	public TeamAlreadyExistException() {
		super();
		// TODO Auto-generated constructor stub
	}

}
