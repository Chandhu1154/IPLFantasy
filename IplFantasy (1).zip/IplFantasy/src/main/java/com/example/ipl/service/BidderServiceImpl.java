package com.example.ipl.service;

import java.util.ArrayList;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.ipl.repositry.AdminOperationsDao;
import com.example.ipl.repositry.BidderDao;
import com.example.ipl.repositry.BtsDao;
import com.example.ipl.dto.BidderDto;
import com.example.ipl.dto.BiddingDto;
import com.example.ipl.dto.MatchDto;
import com.example.ipl.entities.Bidder;
import com.example.ipl.entities.BiddingDetails;
import com.example.ipl.entities.MatchDetails;
import com.example.ipl.entities.TeamDetails;
import com.example.ipl.exception.BidAlreadyExistForBidderException;
import com.example.ipl.exception.BidNotFoundException;
import com.example.ipl.exception.MatchNotFoundException;
import com.example.ipl.exception.UserAlreadyExistException;
import com.example.ipl.exception.UserNotExistException;
@Service
public class BidderServiceImpl implements IBidderService{
@Autowired
 BidderDao bidderDao;
@Autowired
  AdminOperationsDao adminOperationDao;
@Autowired
  BtsDao btsDao;
	@Override
	public Bidder registerBidder(BidderDto b) throws UserAlreadyExistException{
		if(bidderDao.findByEmail(b.getEmail()).isEmpty())
		{
			Bidder bidder=new Bidder();
			bidder.setBidderId(b.getBidderId());
			bidder.setBiddingDetails(b.getBiddingDetails());
			bidder.setEmail(b.getEmail());
			bidder.setName(b.getName());
			bidder.setPassword(b.getPassword());
			bidder.setPhoneNo(b.getPhoneNo());
			bidder.setPoints(b.getPoints());
			bidder.setUserName(b.getUserName());
			return bidderDao.save(bidder);
		
		}
		else
		{
			throw new UserAlreadyExistException();
		}
			
			
           
		
		
	}
	@Override
	public String loginBidder(BidderDto b) throws UserNotExistException{
		if(bidderDao.userExist(b.getUserName(), b.getPassword()).isEmpty())
		{
			throw new UserNotExistException();
		}
		else
		{
			return "Login succesfully";
		}
		
	}
	@Override
	public BiddingDetails addBid(BiddingDto bd) throws BidAlreadyExistForBidderException{
	  if(btsDao.existsById(bd.getBidder().getBidderId()))
	  {
		throw new BidAlreadyExistForBidderException();
	  }
	  else
	  {
		  BiddingDetails biddingDetails=new BiddingDetails();
			biddingDetails.setBidder(bd.getBidder());
			biddingDetails.setBiddingId(bd.getBiddingId());
			biddingDetails.setMatchDetails(bd.getMatchDetails());
			biddingDetails.setTeamDetails(bd.getTeamDetails());
			return btsDao.save(biddingDetails);
	  }
	}
	@Override
	public List<MatchDto> getAllMatches() throws MatchNotFoundException {
		
		Iterable<MatchDetails> matchdetails=adminOperationDao.findAll();
		List<MatchDto> matchDtoList=new ArrayList<MatchDto>();
		matchdetails.forEach(matches->{
			MatchDto matchDto=new MatchDto();
			matchDto.setDate(matches.getDate());
			matchDto.setMatchId(matches.getMatchId());
			matchDto.setStadium(matches.getStadium());
			matchDto.setTime(matches.getTime());
			matchDto.setTeamDetails1(matches.getTeamDetails1());
			matchDto.setTeamDetails2(matches.getTeamDetails2());
			matchDto.setWinner(matches.getWinner());
			matchDtoList.add(matchDto);
		});
		if(matchDtoList.isEmpty())
		{
			throw new MatchNotFoundException();
		}
	    return matchDtoList;
		
	}

	@Override
	public void updateBid(int id,int td) throws BidNotFoundException{
		if(btsDao.existsById(id))
		{
		BiddingDetails bd=btsDao.findById(id).get();
		TeamDetails teamDetails=new TeamDetails();
		teamDetails.setTeamId(td);
		bd.setTeamDetails(teamDetails);
		btsDao.save(bd);
		}
		else
		{
			throw new BidNotFoundException();
		}
		
	}
	@Override
	public void deleteBidById(int id) throws BidNotFoundException{

	BiddingDetails b= btsDao.findByBidderId(id);
		if(b!= null)
		{
            int biddingId=b.getBiddingId();
			btsDao.deleteById(biddingId);
	}
		else
		{
			throw new BidNotFoundException();
		}
	}
	@Override
	public int getResult(int id) throws MatchNotFoundException {
		if(adminOperationDao.existsById(id))
		{
		MatchDetails md=adminOperationDao.findById(id).get();
		MatchDto matchDto=new MatchDto();
		matchDto.setDate(md.getDate());
		matchDto.setMatchId(md.getMatchId());
		matchDto.setStadium(md.getStadium());
		matchDto.setTime(md.getTime());
		matchDto.setTeamDetails1(md.getTeamDetails1());
		matchDto.setTeamDetails2(md.getTeamDetails2());
		matchDto.setWinner(md.getWinner());
		return matchDto.getWinner();
		}
		else
		{
			throw new MatchNotFoundException();
		}
	}



}
