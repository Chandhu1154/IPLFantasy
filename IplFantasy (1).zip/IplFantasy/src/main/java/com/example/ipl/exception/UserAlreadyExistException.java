package com.example.ipl.exception;

public class UserAlreadyExistException extends Exception {

	public UserAlreadyExistException() {
		super();
		// TODO Auto-generated constructor stub
	}

}
