package com.example.ipl.exception;

public class BidNotFoundException extends Exception{

	public BidNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

}
